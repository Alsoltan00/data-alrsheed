let currentUser = null;
let selectedFile = null;

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Login form
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    
    // Tab switching
    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchTab(this.dataset.section);
        });
    });
    
    // File upload
    const fileInput = document.getElementById('fileInput');
    const uploadArea = document.getElementById('uploadArea');
    const uploadBtn = document.getElementById('uploadBtn');
    
    uploadArea.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);
    uploadBtn.addEventListener('click', uploadFile);
    
    // Drag and drop
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);
    
    // Search
    document.getElementById('searchBtn').addEventListener('click', searchData);
    document.getElementById('searchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchData();
        }
    });
    
    // Add user
    document.getElementById('addUserBtn').addEventListener('click', handleAddUser);
}

// Authentication functions
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            showMainContent();
            showAlert('تم تسجيل الدخول بنجاح', 'success');
        } else {
            showAlert(data.error || 'خطأ في تسجيل الدخول', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

async function handleLogout() {
    try {
        await fetch('/api/auth/logout', { method: 'POST' });
        currentUser = null;
        showLoginSection();
        showAlert('تم تسجيل الخروج بنجاح', 'success');
    } catch (error) {
        showAlert('خطأ في تسجيل الخروج', 'error');
    }
}

async function checkAuth() {
    try {
        const response = await fetch('/api/auth/check');
        const data = await response.json();
        
        if (response.ok && data.authenticated) {
            currentUser = data.user;
            showMainContent();
        } else {
            showLoginSection();
        }
    } catch (error) {
        showLoginSection();
    }
}

function showLoginSection() {
    document.getElementById('loginSection').style.display = 'block';
    document.getElementById('mainContent').style.display = 'none';
    document.getElementById('userInfo').style.display = 'none';
    document.getElementById('logoutBtn').style.display = 'none';
}

function showMainContent() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
    document.getElementById('userInfo').style.display = 'flex';
    document.getElementById('logoutBtn').style.display = 'flex';
    
    // Update user info
    document.getElementById('username').textContent = currentUser.username;
    document.getElementById('userRole').textContent = currentUser.role === 'admin' ? 'إدارة كاملة' : 'البحث فقط';
    
    // Show/hide tabs based on user role
    if (currentUser.role === 'admin') {
        // Admin can see all tabs
        document.getElementById('uploadTab').style.display = 'flex';
        document.getElementById('statsTab').style.display = 'flex';
        document.getElementById('usersTab').style.display = 'flex';
        document.getElementById('searchTab').style.display = 'flex';
        
        // Load admin data
        loadStats();
        loadUsers();
        
        // Default to search tab for admin
        switchTab('search');
    } else {
        // Search-only user can only see search tab
        document.getElementById('uploadTab').style.display = 'none';
        document.getElementById('statsTab').style.display = 'none';
        document.getElementById('usersTab').style.display = 'none';
        document.getElementById('searchTab').style.display = 'flex';
        
        // Force switch to search tab and hide others
        switchTab('search');
    }
}

// Tab switching
function switchTab(section) {
    // Update tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-section="${section}"]`).classList.add('active');
    
    // Update content sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(section + 'Section').classList.add('active');
    
    // Load section-specific data
    if (section === 'stats') {
        loadStats();
    } else if (section === 'users' && currentUser.role === 'admin') {
        loadUsers();
    }
}

// File upload functions
function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        selectedFile = file;
        updateUploadArea(file.name);
    }
}

function handleDragOver(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    document.getElementById('uploadArea').classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        selectedFile = files[0];
        updateUploadArea(files[0].name);
    }
}

function updateUploadArea(filename) {
    const uploadArea = document.getElementById("uploadArea");
    uploadArea.innerHTML = `
        <div class="upload-icon">
            <i class="fas fa-file-excel" style="color: #10b981;"></i>
        </div>
        <div class="upload-text">تم اختيار الملف: ${filename}</div>
        <div class="upload-subtext">انقر على "رفع الملف" للمتابعة</div>
        <button class="upload-btn" id="uploadBtn" onclick="uploadFile()">رفع الملف</button>
    `;
}

async function uploadFile() {
    if (!selectedFile) {
        showAlert('يرجى اختيار ملف أولاً', 'error');
        return;
    }
    
    if (currentUser.role !== 'admin') {
        showAlert('غير مصرح لك برفع الملفات', 'error');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', selectedFile);
    
    try {
        document.getElementById('uploadBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الرفع...';
        
        const response = await fetch('/api/inventory/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert(`تم رفع الملف بنجاح! تم إضافة ${data.total_rows} صف`, 'success');
            resetUploadArea();
            loadStats();
        } else {
            showAlert(data.error || 'خطأ في رفع الملف', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    } finally {
        document.getElementById('uploadBtn').innerHTML = '<i class="fas fa-upload"></i> رفع الملف';
    }
}

function resetUploadArea() {
    selectedFile = null;
    document.getElementById('fileInput').value = '';
    document.getElementById('uploadArea').innerHTML = `
        <div class="upload-icon">
            <i class="fas fa-cloud-upload-alt"></i>
        </div>
        <div class="upload-text">اسحب وأفلت ملف Excel هنا</div>
        <div class="upload-subtext">أو انقر لاختيار ملف</div>
    `;
    document.getElementById('uploadBtn').style.display = 'none';
}

// Search functions
async function searchData() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    
    if (!searchTerm) {
        showAlert('يرجى إدخال كلمة البحث', 'error');
        return;
    }
    
    try {
        document.getElementById('searchBtn').innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري البحث...';
        
        const response = await fetch('/api/inventory/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ search_term: searchTerm })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displaySearchResults(data);
        } else {
            showAlert(data.error || 'خطأ في البحث', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    } finally {
        document.getElementById('searchBtn').innerHTML = '<i class="fas fa-search"></i> بحث';
    }
}

function displaySearchResults(data) {
    const resultsContainer = document.getElementById('searchResults');
    
    if (data.results.length === 0) {
        resultsContainer.innerHTML = `
            <div class="alert error">
                <i class="fas fa-exclamation-triangle"></i>
                لم يتم العثور على نتائج للبحث عن "${data.search_term}"
            </div>
        `;
        return;
    }
    
    let html = `
        <div class="search-message">
            <i class="fas fa-check-circle"></i>
            تم العثور على ${data.total_found} نتيجة للبحث عن "${data.search_term}"
        </div>
        <table class="results-table">
            <thead>
                <tr>
    `;
    
    // Add headers
    if (data.headers && data.headers.length > 0) {
        data.headers.forEach(header => {
            html += `<th>${header}</th>`;
        });
    }
    
    html += `
                </tr>
            </thead>
            <tbody>
    `;
    
    // Add data rows
    data.results.forEach(result => {
        html += '<tr>';
        if (data.headers) {
            data.headers.forEach(header => {
                const value = result.data[header] || '';
                html += `<td>${value}</td>`;
            });
        }
        html += '</tr>';
    });
    
    html += `
            </tbody>
        </table>
    `;
    
    resultsContainer.innerHTML = html;
}

// Stats functions
async function loadStats() {
    try {
        const response = await fetch('/api/inventory/stats');
        const data = await response.json();
        
        if (response.ok) {
            displayStats(data);
        } else {
            showAlert(data.error || 'خطأ في جلب الإحصائيات', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

function displayStats(data) {
    // Update stat numbers
    document.getElementById('totalRows').textContent = data.total_items || 0;
    document.getElementById('totalColumns').textContent = data.headers ? data.headers.length : 0;
    document.getElementById('fileName').textContent = data.filename || 'غير محدد';
    document.getElementById('uploadDate').textContent = data.upload_date ? 
        new Date(data.upload_date).toLocaleDateString('ar-SA') : 'غير محدد';
    
    // Update columns list
    const columnsList = document.getElementById('columnsList');
    const columnsListItems = document.getElementById('columnsListItems');
    
    if (data.headers && data.headers.length > 0) {
        columnsList.style.display = 'block';
        columnsListItems.innerHTML = '';
        data.headers.forEach(header => {
            const li = document.createElement('li');
            li.textContent = header;
            columnsListItems.appendChild(li);
        });
    } else {
        columnsList.style.display = 'none';
    }
}

// User management functions
async function loadUsers() {
    try {
        const response = await fetch('/api/users/');
        const data = await response.json();
        
        if (response.ok) {
            displayUsers(data.users);
        } else {
            showAlert(data.error || 'خطأ في جلب المستخدمين', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('usersTableBody');
    
    if (users.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: #64748b;">
                    <i class="fas fa-users" style="font-size: 2rem; margin-bottom: 10px;"></i>
                    <div>لا توجد مستخدمين</div>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = '';
    users.forEach((user, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${user.username}</td>
            <td>${user.role === 'admin' ? 'إدارة كاملة' : 'البحث فقط'}</td>
            <td>${new Date(user.created_at).toLocaleDateString('ar-SA')}</td>
            <td><span style="color: #10b981; font-weight: 600;">نشط</span></td>
            <td>
                <button class="edit-btn" onclick="showPasswordModal(${user.id}, '${user.username}')" style="margin-left: 5px;">
                    <i class="fas fa-key"></i> تغيير كلمة المرور
                </button>
                ${user.username !== 'admin' ? 
                    `<button class="delete-btn" onclick="deleteUser(${user.id})">
                        <i class="fas fa-trash"></i> حذف
                    </button>` : 
                    ''
                }
            </td>
        `;
        tbody.appendChild(row);
    });
}

function showPasswordModal(userId, username) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>تغيير كلمة المرور</h3>
                <button class="modal-close" onclick="closePasswordModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p>تغيير كلمة المرور للمستخدم: <strong>${username}</strong></p>
                <div class="form-group">
                    <label>كلمة المرور الجديدة</label>
                    <input type="password" id="newPasswordInput" placeholder="أدخل كلمة المرور الجديدة" minlength="6">
                </div>
                <div class="form-group">
                    <label>تأكيد كلمة المرور</label>
                    <input type="password" id="confirmPasswordInput" placeholder="أعد إدخال كلمة المرور">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn-secondary" onclick="closePasswordModal()">إلغاء</button>
                <button class="btn-primary" onclick="updatePassword(${userId})">تحديث</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    document.getElementById('newPasswordInput').focus();
}

function closePasswordModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.remove();
    }
}

async function updatePassword(userId) {
    const newPassword = document.getElementById('newPasswordInput').value.trim();
    const confirmPassword = document.getElementById('confirmPasswordInput').value.trim();
    
    if (!newPassword || !confirmPassword) {
        showAlert('يرجى ملء جميع الحقول', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showAlert('كلمة المرور وتأكيدها غير متطابقين', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showAlert('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
        return;
    }
    
    try {
        const response = await fetch(`/api/users/${userId}/password`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ password: newPassword })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('تم تحديث كلمة المرور بنجاح', 'success');
            closePasswordModal();
            loadUsers();
        } else {
            showAlert(data.error || 'خطأ في تحديث كلمة المرور', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

async function handleAddUser() {
    const username = document.getElementById('newUsername').value.trim();
    const password = document.getElementById('newPassword').value.trim();
    const role = document.getElementById('newRole').value;
    
    if (!username || !password) {
        showAlert('يرجى ملء جميع الحقول', 'error');
        return;
    }
    
    if (currentUser.role !== 'admin') {
        showAlert('غير مصرح لك بإضافة مستخدمين', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/users/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, role })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('تم إضافة المستخدم بنجاح', 'success');
            document.getElementById('newUsername').value = '';
            document.getElementById('newPassword').value = '';
            document.getElementById('newRole').value = 'search';
            loadUsers();
        } else {
            showAlert(data.error || 'خطأ في إضافة المستخدم', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/users/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showAlert('تم حذف المستخدم بنجاح', 'success');
            loadUsers();
        } else {
            showAlert(data.error || 'خطأ في حذف المستخدم', 'error');
        }
    } catch (error) {
        showAlert('خطأ في الاتصال بالخادم', 'error');
    }
}

// Utility functions
function showAlert(message, type) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Create new alert
    const alert = document.createElement('div');
    alert.className = `alert ${type}`;
    alert.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i>
        ${message}
    `;
    
    // Insert at the top of the container
    const container = document.querySelector('.container');
    container.insertBefore(alert, container.firstChild);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}

